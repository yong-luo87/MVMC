#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>


#include "mex.h"
#include "matrix.h"

#define GETMATIDX(n,N,M)
#define GETIDXMAT(i,j,N,M)

#ifndef max
	#define max( a, b ) ( ((a) > (b)) ? (a) : (b) )
#endif

/* prototype: int mxUnshareArray(mxArray *); */
int mxUnshareArray(mxArray *, int);


int cmp_func(const void* elem1, const void* elem2)
{
    if(*(const double*)elem1 < *(const double*)elem2)
        return -1;
    return *(const double*)elem1 > *(const double*)elem2;
}

void proj(double *sortedptr, double *originaldata, int hist_len) {
	double sum = 0;
	double rho = hist_len;
	int i;
	double theta;
	double *debug,s;
	
	/* figure out rho: smallest element for which mu_i - 1/i*(sum-1) holds */
	for(i=0;i<hist_len;i++) {
		sum += sortedptr[hist_len-i-1]; /* ptr is sorted in ascending order */
		debug = &sortedptr[hist_len-i-1];
		s= (1/((double)i+1)) *(sum -1);
		if(sortedptr[hist_len-i-1] <= s){
			sum -=sortedptr[hist_len-i-1];
			rho = i;
			break;
		}
	}
	
	/* calculate theta */
	theta = (1/rho)*(sum-1);
	
	/* truncate elements as max(ptr[i] - theta, 0) */
	for(i=0;i<hist_len;i++)
		originaldata[i] = max((originaldata[i]-theta), 0);
}

void mexFunction(int nlhs, mxArray *plhs[],
					int nrhs, const mxArray *prhs[]) {
	double *featmap, *histsize, *dataptr, *sortptr;
	size_t N, F;
	int nr_hists, curhistidx;
	int curimg, hist, bin;
	
	/* check number of inputs/outputs*/
	if(nlhs != 0|| nrhs != 2)
		mexErrMsgTxt("wrong input/output params: proj_Simplex(Z, histsizes), Z in [400+40+40+40] x N\n");
	
	/* hacky stuff: make matrix be unshared with others that reference it */
	/* http://www.mathkb.com/Uwe/Forum.aspx/matlab/65197/What-s-mex-good-for */
	mxUnshareArray(prhs[0], 0);
	
	
	featmap = mxGetPr(prhs[0]);
	
	N = mxGetN(prhs[0]);
	F = mxGetM(prhs[0]);

	histsize =  mxGetPr(prhs[1]);
	nr_hists = max(mxGetN(prhs[1]), mxGetM(prhs[1]));

	/* Projection loop */
	dataptr = featmap; /* point at beginning of matrix */ 
	curhistidx = 0;
	for(hist=0; hist < nr_hists; hist++) {

		
		if(!(sortptr = malloc(histsize[hist]*sizeof(double))))
			mexErrMsgTxt("Malloc error");
		
		/* project vector onto prob simplex */
		for(curimg = 0; curimg < N; curimg++) {
			
			
			/* copy the image histogram into array for sorting */
			dataptr = &featmap[curhistidx + curimg*F];
			for(bin = 0; bin < histsize[hist]; bin++)
				sortptr[bin] = dataptr[bin];
			
			qsort(sortptr, histsize[hist], sizeof(double), cmp_func);
			proj(sortptr, dataptr, histsize[hist]);
			
		}
		
		curhistidx += histsize[hist];
		free(sortptr);
	}

	/* create output structures*/	
	/*
		mexPrintf("Create Output...\n");
		plhs[0] = mxCreateDoubleMatrix(N, M, mxREAL);	
		output = (double *) mxGetPr(plhs[0]);
		output[0] =  optimal_box->l_lo;
		output[1] = optimal_box->t_lo;
		output[2] =  optimal_box->t_lo;
		output[3] = optimal_box->b_lo;
	*/	
	return;
}
